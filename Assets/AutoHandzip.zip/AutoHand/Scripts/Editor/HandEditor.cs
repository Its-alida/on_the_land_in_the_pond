using UnityEditor;
using UnityEngine;

namespace Autohand {
    //[CustomEditor(typeof(Hand)), CanEditMultipleObjects]
    public class HandEditor : Editor {

    }
}
